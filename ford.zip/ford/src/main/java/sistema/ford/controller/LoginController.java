package sistema.ford.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sistema.ford.service.LoginService;
import sistema.ford.usuarioDTO.UsuarioAutenticacaoDTO;

@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping("/verificaLogin")
    public Boolean verificaLogin(@RequestBody UsuarioAutenticacaoDTO dados){
        return loginService.verificaUsuarioExistente(dados);
    }

}
