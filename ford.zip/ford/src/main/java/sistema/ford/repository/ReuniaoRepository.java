package sistema.ford.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sistema.ford.model.Reuniao;

public interface ReuniaoRepository extends JpaRepository<Reuniao, Long> {
}
