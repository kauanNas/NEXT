package sistema.ford.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sistema.ford.model.Usuario;
import sistema.ford.repository.UsuarioRepository;
import sistema.ford.usuarioDTO.UsuarioAutenticacaoDTO;

import java.util.List;

@Service
public class LoginService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public Boolean verificaUsuarioExistente(UsuarioAutenticacaoDTO dados){
        List<Usuario> usuarioList = usuarioRepository.findAll();
        for(Usuario usuario : usuarioList){
            String email = usuario.getEmail();
            String senha = usuario.getSenha();
            if(email.equals(dados.email()) && senha.equals(dados.senha())){
                return true;
            }
        }
        return false;
    }

}
