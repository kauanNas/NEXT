package sistema.ford.usuarioDTO;

public record CadastroUsuarioDTO(String email, String senha,  String nome) {
}
