package sistema.ford.usuarioDTO;

public record UsuarioAutenticacaoDTO(String email, String senha) {

}
