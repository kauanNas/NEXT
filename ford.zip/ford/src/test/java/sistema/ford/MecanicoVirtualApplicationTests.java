package sistema.ford;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MecanicoVirtualApplicationTests {

	@Test
	void contextLoads() {
	}

}
